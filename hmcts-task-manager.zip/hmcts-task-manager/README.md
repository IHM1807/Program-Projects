# HMCTS Task Manager

A full-stack task management application for HMCTS caseworkers.

## Tech Stack

### Backend
- Java 17
- Spring Boot 3
- Spring Web
- Spring Data JPA
- H2 in-memory database
- Jakarta Validation
- JUnit 5 / Mockito
- Swagger / OpenAPI

### Frontend
- React
- Vite
- Axios
- Vitest
- React Testing Library

## Project Structure

```text
hmcts-task-manager/
├── backend/
└── frontend/
```

## Running the Backend

```bash
cd backend
./mvnw spring-boot:run
```

On Windows:

```bash
cd backend
mvnw.cmd spring-boot:run
```

Backend runs at:

```text
http://localhost:8080
```

Swagger API documentation:

```text
http://localhost:8080/swagger-ui/index.html
```

H2 database console:

```text
http://localhost:8080/h2-console
```

Use:

```text
JDBC URL: jdbc:h2:mem:tasksdb
Username: sa
Password:
```

## Running the Frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend runs at:

```text
http://localhost:5173
```

## Running Tests

Backend:

```bash
cd backend
./mvnw test
```

Frontend:

```bash
cd frontend
npm install
npm test
```

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/tasks` | Create a task |
| GET | `/api/tasks` | Retrieve all tasks |
| GET | `/api/tasks/{id}` | Retrieve a task by ID |
| PATCH | `/api/tasks/{id}/status` | Update task status |
| DELETE | `/api/tasks/{id}` | Delete a task |

## Example Create Task Request

```json
{
  "title": "Review case file",
  "description": "Check all documents before hearing",
  "status": "TODO",
  "dueDateTime": "2026-07-01T10:00:00"
}
```

## Task Status Values

```text
TODO
IN_PROGRESS
DONE
```

## Assumptions

- Description is optional.
- Title is required.
- Status is required.
- Due date/time is required and cannot be in the past.
- This submission uses H2 for simple local testing.
- PostgreSQL could be added later for production-style persistence.

## Future Improvements

- Authentication and role-based access.
- Pagination and filtering.
- PostgreSQL with Docker Compose.
- More frontend component tests.
- CI pipeline using GitHub Actions.
