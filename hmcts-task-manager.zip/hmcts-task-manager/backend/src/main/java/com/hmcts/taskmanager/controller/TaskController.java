package com.hmcts.taskmanager.controller;

import com.hmcts.taskmanager.dto.CreateTaskRequest;
import com.hmcts.taskmanager.dto.UpdateStatusRequest;
import com.hmcts.taskmanager.model.Task;
import com.hmcts.taskmanager.service.TaskService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    private final TaskService service;

    public TaskController(TaskService service) {
        this.service = service;
    }

    @Operation(summary = "Create a new task")
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Task createTask(@Valid @RequestBody CreateTaskRequest request) {
        return service.createTask(request);
    }

    @Operation(summary = "Retrieve a task by ID")
    @GetMapping("/{id}")
    public Task getTaskById(@PathVariable Long id) {
        return service.getTaskById(id);
    }

    @Operation(summary = "Retrieve all tasks")
    @GetMapping
    public List<Task> getAllTasks() {
        return service.getAllTasks();
    }

    @Operation(summary = "Update the status of a task")
    @PatchMapping("/{id}/status")
    public Task updateStatus(
            @PathVariable Long id,
            @Valid @RequestBody UpdateStatusRequest request
    ) {
        return service.updateStatus(id, request.getStatus());
    }

    @Operation(summary = "Delete a task")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteTask(@PathVariable Long id) {
        service.deleteTask(id);
    }
}
