package com.hmcts.taskmanager.model;

public enum TaskStatus {
    TODO,
    IN_PROGRESS,
    DONE
}
