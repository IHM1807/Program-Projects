package com.hmcts.taskmanager.service;

import com.hmcts.taskmanager.dto.CreateTaskRequest;
import com.hmcts.taskmanager.exception.TaskNotFoundException;
import com.hmcts.taskmanager.model.Task;
import com.hmcts.taskmanager.model.TaskStatus;
import com.hmcts.taskmanager.repository.TaskRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class TaskService {

    private final TaskRepository repository;

    public TaskService(TaskRepository repository) {
        this.repository = repository;
    }

    public Task createTask(CreateTaskRequest request) {
        Task task = new Task(
                request.getTitle(),
                request.getDescription(),
                request.getStatus(),
                request.getDueDateTime()
        );

        return repository.save(task);
    }

    public Task getTaskById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new TaskNotFoundException(id));
    }

    public List<Task> getAllTasks() {
        return repository.findAll();
    }

    public Task updateStatus(Long id, TaskStatus status) {
        Task task = getTaskById(id);
        task.setStatus(status);
        return repository.save(task);
    }

    public void deleteTask(Long id) {
        Task task = getTaskById(id);
        repository.delete(task);
    }
}
