package com.hmcts.taskmanager.service;

import com.hmcts.taskmanager.exception.TaskNotFoundException;
import com.hmcts.taskmanager.model.Task;
import com.hmcts.taskmanager.model.TaskStatus;
import com.hmcts.taskmanager.repository.TaskRepository;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class TaskServiceTest {

    private final TaskRepository repository = mock(TaskRepository.class);
    private final TaskService service = new TaskService(repository);

    @Test
    void shouldReturnTaskByIdWhenTaskExists() {
        Task task = new Task("Review case", "Check documents", TaskStatus.TODO, LocalDateTime.now().plusDays(1));

        when(repository.findById(1L)).thenReturn(Optional.of(task));

        Task result = service.getTaskById(1L);

        assertEquals("Review case", result.getTitle());
    }

    @Test
    void shouldThrowExceptionWhenTaskNotFound() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(TaskNotFoundException.class, () -> service.getTaskById(99L));
    }

    @Test
    void shouldUpdateTaskStatus() {
        Task task = new Task("Review case", "Check documents", TaskStatus.TODO, LocalDateTime.now().plusDays(1));

        when(repository.findById(1L)).thenReturn(Optional.of(task));
        when(repository.save(task)).thenReturn(task);

        Task result = service.updateStatus(1L, TaskStatus.DONE);

        assertEquals(TaskStatus.DONE, result.getStatus());
        verify(repository).save(task);
    }
}
