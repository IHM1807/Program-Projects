import { useEffect, useState } from "react";
import {
  createTask,
  deleteTask,
  getTasks,
  updateTaskStatus,
} from "./api/taskApi";
import TaskForm from "./components/TaskForm";
import TaskList from "./components/TaskList";

function App() {
  const [tasks, setTasks] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const loadTasks = async () => {
    setLoading(true);
    setError("");

    try {
      const response = await getTasks();
      setTasks(response.data);
    } catch {
      setError("Could not load tasks. Please check the backend is running.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTasks();
  }, []);

  const handleCreate = async (task) => {
    setError("");

    try {
      await createTask(task);
      await loadTasks();
    } catch {
      setError("Please complete all required fields correctly.");
    }
  };

  const handleStatusChange = async (id, status) => {
    setError("");

    try {
      await updateTaskStatus(id, status);
      await loadTasks();
    } catch {
      setError("Could not update task status.");
    }
  };

  const handleDelete = async (id) => {
    setError("");

    try {
      await deleteTask(id);
      await loadTasks();
    } catch {
      setError("Could not delete task.");
    }
  };

  return (
    <main className="container">
      <header className="header">
        <h1>HMCTS Task Manager</h1>
        <p>Manage caseworker tasks, deadlines, and progress.</p>
      </header>

      <TaskForm onCreate={handleCreate} />

      {error && <p className="error" role="alert">{error}</p>}
      {loading ? (
        <p>Loading tasks...</p>
      ) : (
        <TaskList
          tasks={tasks}
          onStatusChange={handleStatusChange}
          onDelete={handleDelete}
        />
      )}
    </main>
  );
}

export default App;
