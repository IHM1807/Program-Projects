import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import App from "./App";

vi.mock("./api/taskApi", () => ({
  getTasks: () => Promise.resolve({ data: [] }),
  createTask: vi.fn(),
  updateTaskStatus: vi.fn(),
  deleteTask: vi.fn(),
}));

describe("App", () => {
  it("renders the page title", async () => {
    render(<App />);
    expect(await screen.findByText("HMCTS Task Manager")).toBeInTheDocument();
  });
});
