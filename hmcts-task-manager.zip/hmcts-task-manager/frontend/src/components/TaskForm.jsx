import { useState } from "react";

const initialForm = {
  title: "",
  description: "",
  status: "TODO",
  dueDateTime: "",
};

function TaskForm({ onCreate }) {
  const [form, setForm] = useState(initialForm);

  const handleSubmit = async (event) => {
    event.preventDefault();
    await onCreate(form);
    setForm(initialForm);
  };

  return (
    <form onSubmit={handleSubmit} className="task-form">
      <h2>Create task</h2>

      <label>
        Title
        <input
          type="text"
          placeholder="Review case file"
          value={form.title}
          onChange={(event) => setForm({ ...form, title: event.target.value })}
        />
      </label>

      <label>
        Description optional
        <textarea
          placeholder="Add task details"
          value={form.description}
          onChange={(event) =>
            setForm({ ...form, description: event.target.value })
          }
        />
      </label>

      <label>
        Status
        <select
          value={form.status}
          onChange={(event) => setForm({ ...form, status: event.target.value })}
        >
          <option value="TODO">TODO</option>
          <option value="IN_PROGRESS">IN_PROGRESS</option>
          <option value="DONE">DONE</option>
        </select>
      </label>

      <label>
        Due date and time
        <input
          type="datetime-local"
          value={form.dueDateTime}
          onChange={(event) =>
            setForm({ ...form, dueDateTime: event.target.value })
          }
        />
      </label>

      <button type="submit">Create Task</button>
    </form>
  );
}

export default TaskForm;
