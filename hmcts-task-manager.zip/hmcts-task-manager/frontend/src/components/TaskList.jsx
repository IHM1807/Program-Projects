function TaskList({ tasks, onStatusChange, onDelete }) {
  if (tasks.length === 0) {
    return <p className="empty-state">No tasks have been created yet.</p>;
  }

  return (
    <section className="task-list" aria-label="Task list">
      {tasks.map((task) => (
        <article key={task.id} className="task-card">
          <div>
            <h2>{task.title}</h2>
            {task.description && <p>{task.description}</p>}
            <p>
              <strong>Due:</strong> {new Date(task.dueDateTime).toLocaleString()}
            </p>
          </div>

          <div className="task-actions">
            <label>
              Status
              <select
                value={task.status}
                onChange={(event) => onStatusChange(task.id, event.target.value)}
              >
                <option value="TODO">TODO</option>
                <option value="IN_PROGRESS">IN_PROGRESS</option>
                <option value="DONE">DONE</option>
              </select>
            </label>

            <button className="delete-button" onClick={() => onDelete(task.id)}>
              Delete
            </button>
          </div>
        </article>
      ))}
    </section>
  );
}

export default TaskList;
